metadata(description="Lightweight MQTT client for MicroPython.", version="1.8.1")

# Originally written by Paul Sokolovsky.

require("ssl")

package("umqtt")
