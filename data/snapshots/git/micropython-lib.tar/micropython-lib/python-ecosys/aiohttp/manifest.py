metadata(
    description="HTTP client module for MicroPython asyncio module",
    version="0.0.8",
    pypi="aiohttp",
)

package("aiohttp")
